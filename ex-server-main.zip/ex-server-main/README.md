# ex-server
 demo-project-for-git

Steps - 
1. Clone the project / download and extract it. 

On CMD, in the project folder 
2.  run the command 
npm install 

3. run the command 
node index.js 

In browser 
4. see the output at http://localhost:3333 